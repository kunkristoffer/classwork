"use strict"
// hente data med fetch + .then:

// 1. første .then:
/*
Response { 
  type: "cors", 
  url: "https://cataas.com/cat?json=true", 
  redirected: false, 
  status: 200, 
  ok: true, 
  statusText: "OK", 
  headers: Headers(1), 
  body: ReadableStream, 
  bodyUsed: false 
}
​

*/

function displayData(data) {
  const dataContainer = document.getElementById("my-data")
  dataContainer.textContent = JSON.stringify(data, null, 1)
  console.log(data)

}






async function apiRequest(url) {
  try {
    const request = await fetch(url, 
      { 
      method: "PATCH",
      body: JSON.stringify({
        id: 1,
        title: 'iuguiagdg',
        body: 'bar',
        userId: 1,
      }),
      headers: {
        'Content-type': 'application/json; charset=UTF-8',
      },
    })

    // check if the reuquest is "ok"
    if (request.status !== 200) return

    console.log("status: " + request.status)
    console.log("ok: " + request.ok)

    const data = await request.json()
    
    // først vis katten
    displayData(data)
  }
  catch(error) {
    displayUserFriendlyErrorMessage()
    console.log(error)
  }
  
  // så vis noe annet
  // ....
}

apiRequest("https://jsonplaceholder.typicode.com/posts/ahj/1")








/* fetch("!#%https://cataas.com/cat?json=true")
  .then((request) => {
    //console.log(request)
    return request.json()
  })
  .then((data) => {
    // først vis katten
    displayCat(data)
    // så vis noe annet
    // ....
  })
  .catch((error) => console.log(error))
  .finally(() => console.log("finally")) */





///// shopping cart & errors
/* const shoppingItemElements = document.querySelectorAll(".item button")

shoppingItemElements.forEach((button) => button.addEventListener("click", addToCart))

let totalPrice = 0;
const totalPriceEl = document.getElementById("totalPrice") */

function addToCart() {

  totalPrice += 10;

  try {
    console.log("Trying")
    //checkItemStatus()
    totalPriceEl.textContent = totalPrice
  }
  catch(error) {
    console.log("Catching")
    console.log(error)
  }
  finally {

    // clean up totalPrice change:
    
    //console.log("Finalizing")
    //console.log()
  }

  console.log("All Done!")

  console.log(totalPrice)
}




//try {
  //checkItemStatus()
//}
//catch (error) {
  //console.log(error)
//}

//console.log("This is still running despite error!")